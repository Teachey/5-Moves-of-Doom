From START screen, click enter (on PC) or start on (on GBA) to go to the
INSTRUCTIONS screen.
From INSTRUCTIONS screen, click enter or start to go to the GAME screen.
Press A and S (on PC) or L and R (on GBA) to jump rope.
Press Z and X (on PC) or B and A (on GBA) to do push-ups.
Press the left and right arrow keys to do leg presses.
From GAME screen, click enter or start to go to the PAUSE screen.
From PAUSE screen, click backspace (on PC) or select (on GBA) to return to the
start screen.
From PAUSE screen, click enter or start to return to the GAME screen.
From LOSE screen, click enter or start to return to the START screen.
From WIN screen, click enter or start to return to the START screen.

To win, you must complete 20 revolutions of the jump rope (I'm not sure if
revolutions is the correct word) within the first 10 seconds of the game,
20 pushups within the first 20 seconds of the game, and 20 leg presses, within
the first 30 seconds of the game. These mini-games must be completed in order.
If you fail at any of these mini-games then you lose the entire game.

_______________________________________________________________________________

I'm having trouble displaying my timer. Right now, I only have sprites for 0-10,
but I will add more when I get the first 10 seconds working. From reading my
main.c file and looking at badSprites, can you tell what the problem is?

For the record, the number of push-ups and such that the player completed is
intentionally not displayed for authenticity. If you were training for a
marathon, you wouldn’t know exactly how hard you will have to train in order to
win. In this readme file I wrote that it takes 20 of each task, but I don't
plan on including that on the INSTRUCTIONS screen. I will probably just refer
to it as "a certain number."

Speaking of instructions, if I want my INSTRUCTIONS state to have an XL
background how do I do that?

If you look in main.c, you will see the numbers 176 and 168 repeated often. I
don't want to violate the DRY principle so I plan on making a variable for these
values. The reason why I haven't done that already is because I honestly don't
know why these numbers work. In each scenario where 176 and 168 are used, I want
the player to do something 20 times. I'm pretty sure the discrepancy has
something to do with the fact that one int equals four bytes, but this math
isn't adding up to me. To get these numbers I basically just did a manual binary
search until I found numbers that worked. Do you understand what's going on?

As we're nearing the end of the semester, I'm beginning to doubt whether I will
be able to complete the wrestling match/ final boss I had envisioned. Instead I
would like to leave the win/loss conditions the way they are; add a jump rope,
a leg press, and a mat as sprites; when the player touches one of those objects,
then the mini-game begins. I plan on conducting play tests in order to better
determine the amount of each exercise the player should do and how much time
he should be allotted. The way the game is now you must complete 20
of each exercise, but for the cheat, I could make it so that if the player does
exactly 10 of a certain exercise then they get extra time on the next exercise.
How does all that sound?
