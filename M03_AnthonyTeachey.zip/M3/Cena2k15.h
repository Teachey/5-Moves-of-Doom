
//{{BLOCK(Cena2k15)

//======================================================================
//
//	Cena2k15, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 436 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 13952 + 2048 = 16512
//
//	Time-stamp: 2018-11-11, 13:17:02
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_CENA2K15_H
#define GRIT_CENA2K15_H

#define Cena2k15TilesLen 13952
extern const unsigned short Cena2k15Tiles[6976];

#define Cena2k15MapLen 2048
extern const unsigned short Cena2k15Map[1024];

#define Cena2k15PalLen 512
extern const unsigned short Cena2k15Pal[256];

#endif // GRIT_CENA2K15_H

//}}BLOCK(Cena2k15)
