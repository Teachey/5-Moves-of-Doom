From START screen, click enter (on PC) or start on (on GBA) to go to the
INSTRUCTIONS screen.
From INSTRUCTIONS screen, click enter or start to go to the GAME screen.
Press A and S (on PC) or L and R (on GBA) to jump rope.
Press Z and X (on PC) or B and A (on GBA) to do push-ups.
Press the left and right arrow keys to do leg presses.
From GAME screen, click enter or start to go to the PAUSE screen.
From PAUSE screen, click backspace (on PC) or select (on GBA) to return to the
start screen.
From PAUSE screen, click enter or start to return to the GAME screen.
From GAME screen, click the down arrow key to go to the LOSE screen.
From LOSE screen, click enter or start to return to the START screen.
From GAME screen, click the up arrow key to go to the WIN screen.
From WIN screen, click enter or start to return to the START screen.